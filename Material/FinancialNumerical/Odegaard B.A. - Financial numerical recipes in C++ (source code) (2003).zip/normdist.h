// normdist.h 
// author: Bernt A Oedegaard

#ifndef _NORMAL_DIST_H_
#define _NORMAL_DIST_H_

double n(double z);                          // normal distribution function
double n(double r,double mu, double sigmasqr);  // normal distribution function    
double N(double z);                          // cumulative probability of normal
double N(double a, double b, double rho);    // cum prob of bivariate normal
double random_normal(); // random numbers with mean zero and variance one
#endif

