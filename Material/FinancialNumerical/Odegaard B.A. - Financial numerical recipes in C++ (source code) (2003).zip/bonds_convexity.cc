#include <cmath>
#include <vector>
using namespace std;

double bonds_convexity(const vector<double>& cashflow_times,   
		       const vector<double>& cashflow_amounts,
		       const double& y ) {
    double C=0;
    for (int i=0;i<cashflow_times.size();i++){
	double t = cashflow_times[i];
	C+= cashflow_amounts[i] * t * t * exp(-y*t);
    };
    return C;
};
