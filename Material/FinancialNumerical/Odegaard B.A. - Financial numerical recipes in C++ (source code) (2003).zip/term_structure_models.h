// file term_structure.h
#include <vector>
using namespace std;
#include "fin_recipes.h"

double term_structure_yield_nelson_siegel(const double& t,
					  const double& beta0, const double& beta1, const double& beta2,
					  const double& lambda );


double term_structure_discount_factor_cubic_spline(const double& t,
						   const double& b1,
						   const double& c1,
						   const double& d1,
						   const vector<double>& f,
						   const vector<double>& knots);

double term_structure_discount_factor_cir(const double& t, const double& r,
					  const double& kappa,
					  const double& lambda,
					  const double& theta,
					  const double& sigma);

double term_structure_discount_factor_vasicek(const double& time,
					      const double& r,
					      const double& a,const double& b, const double& sigma);

