#ifndef _TERM_STRUCTURE_CLASS_NELSON_SIEGEL_
#define _TERM_STRUCTURE_CLASS_NELSON_SIEGEL_

#include "term_structure_class.h"

class term_structure_class_nelson_siegel : public term_structure_class {
private: 
    double beta0_, beta1_, beta2_, lambda_;
public:
    term_structure_class_nelson_siegel(const double& beta0, 
				       const double& beta1,
				       const double& beta2, 
				       const double& lambda);
    virtual double yield(const double& T) const;
};

#endif
