double payoff_cash_or_nothing_call(const double& price, const double& X){
    double Q=1;
    if (price>=X) return Q;
    return 0;
};

double payoff_asset_or_nothing_call(const double& price, const double& X){
    if (price>=X) return price;
    return 0;
};
