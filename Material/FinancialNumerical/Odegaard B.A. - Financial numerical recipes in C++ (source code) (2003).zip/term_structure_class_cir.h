#ifndef _TERM_STRUCTURE_CLASS_CIR_ 
#define _TERM_STRUCTURE_CLASS_CIR_ 

#include "term_structure_class.h"

class term_structure_class_cir : public term_structure_class {
private: 
    double r_;                       // interest rate
    double kappa_;                   // mean reversion parameter
    double lambda_;                  // risk aversion
    double theta_;                   // long run mean
    double sigma_;                   // volatility
public:
    term_structure_class_cir(const double& r,
			     const double& k, 
			     const double& l,
			     const double& th,
			     const double& sigma);

    virtual double discount_factor(const double& T) const;
};

#endif
