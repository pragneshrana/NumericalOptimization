// file tst_term_structure.cc

void test_transforms() {
  cout << " testing transformations " << endl;
    double r=0.1;
    double t=1;
    double d=0.9;
    cout << " r= " << r << " t = " << t << " gives disc.fact " 
	 << term_structure_discount_factor_from_yield(r,t) << endl;
    cout << " d= " << d << " t = " << t << " gives yield " 
	 << term_structure_yield_from_discount_factor(d,t) << endl;
    double d1=0.8;
    cout << " implied forward rate, d = " << d << " d1= " << d1 << " t= " << t
	 << " forward = "
	 << term_structure_forward_rate_from_disc_facts(d,d1,t) << endl;
};

void test_interpolated_yield(){
    vector<double> times; 
    times.push_back(0.1); 
    times.push_back(0.5);
    times.push_back(1);
    times.push_back(5);
    times.push_back(10);
    vector<double> yields; 
    yields.push_back(0.1);
    yields.push_back(0.2);
    yields.push_back(0.3);
    yields.push_back(0.4);
    yields.push_back(0.5);
    cout << " testing interpolated " << endl;
    cout << " t=.1 " << term_structure_yield_linearly_interpolated(0.1,times,yields) << endl;
    cout << " t=0.5 " << term_structure_yield_linearly_interpolated(0.5,times,yields) << endl;
    cout << " t=1 " << term_structure_yield_linearly_interpolated(1,times,yields) << endl;
    cout << " t=3 " << term_structure_yield_linearly_interpolated(3,times,yields) << endl;
    cout << " t=5 " << term_structure_yield_linearly_interpolated(5,times,yields) << endl; 
    cout << " t=10 " << term_structure_yield_linearly_interpolated(10,times,yields) << endl;
};

void test_term_structure() {
    cout << "TESTING, term structure calculations " << endl;
    test_transforms();
    test_interpolated_yield();
    cout << "DONE TESTING, term structure calculations " << endl;
};
