#include <vector>
using namespace std;

#include "term_structure_class.h"

double bonds_price(const vector<double>& cashflow_times,  
		   const vector<double>& cashflows,
		   const term_structure_class& d) { 
    double p = 0; 
    for (unsigned i=0;i<cashflow_times.size();i++) { 
	p += d.discount_factor(cashflow_times[i])*cashflows[i];
    };
    return p; 
}; 
