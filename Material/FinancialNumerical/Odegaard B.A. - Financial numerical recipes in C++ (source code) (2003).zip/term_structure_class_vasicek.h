#ifndef _TERM_STRUCTURE_CLASS_VASICEK_ 
#define _TERM_STRUCTURE_CLASS_VASICEK_ 

#include "term_structure_class.h"

class term_structure_class_vasicek : public term_structure_class {
private: 
    double r_;
    double a_;
    double b_;
    double sigma_;
public:
    term_structure_class_vasicek(const double& r,
			     const double& a, 
			     const double& b,
			     const double& sigma);

    virtual double discount_factor(const double& T) const;
};

#endif
