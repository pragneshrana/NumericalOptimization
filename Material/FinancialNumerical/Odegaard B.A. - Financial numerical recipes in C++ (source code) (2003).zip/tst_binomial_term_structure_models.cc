#include <iostream>
using namespace std;

void test_rend_bart_zero_coupon_call() {
    cout << " Zero Coupon Call " << endl;
    double X=1000;                   // exercise price 
    double S=0.15;
    double M=0.05;                   // term structure paramters
    double interest=0.10;            // current short interest rate
    int no_steps=100;
    double option_maturity=4;
    double bond_maturity=5;
    double maturity_payment=1000;
    X=900;
    cout << " option on zero coupon bond " << endl;
    double c = bond_option_price_call_zero_american_rendleman_bartter( X, option_maturity, S, M, 
								       interest, bond_maturity, 
								       maturity_payment, no_steps); 
    cout << "   c = " << c << endl; 
};

/*
void test_rend_bart_coupon_call() {
    double S=0.15;
    double M=0.05;                   // term structure paramters
    double interest=0.10;            // current short interest rate
    int no_steps=5;
    no_steps = 5;
    int no_coupons_z=0;
    double option_maturity=4;
    double bond_maturity=5;
    double maturity_payment=1000;
    double X=1000;
    no_steps = 5;
    int no_coupons=5;
    double bond_coupon_dates[5]={1,2,3,4,5};
    double bond_coupons[5]={80,80,80,80,80};
    cout << " option on coupon bond, example in Hull " << endl;
    double c = calc_rendleman_bartter_american_coupon_bond_call(X, option_maturity,
								S,M,interest,bond_maturity,
								maturity_payment,
								no_coupons,
								bond_coupon_dates,
								bond_coupons,
								no_steps);
    cout << "c = " << c << endl;
};
*/

void test_binomial_term_structure_models(){
    test_rend_bart_zero_coupon_call();
};
