#include <cmath>
#include <algorithm>
#include <vector>
using namespace std;

double 
calc_rendleman_bartter_american_coupon_bond_call(const double& X,                   // exercise price 
						 const double& option_maturity,
						 const double& S, 
						 const double& M,              // term structure paramters
						 const double& interest,      // current short interest rate
						 const double& bond_maturity, // time to maturity for underlying bond
						 const double& maturity_payment,
						 int no_coupons,
						 const vector<double>& bond_coupon_dates,
						 const vector<double>& bond_coupons,
						 int no_steps){
    double delta_t = bond_maturity/no_steps;
 
    double u=exp(S*sqrt(delta_t));
    double d=1/u;
    double p_up = (exp(M*delta_t)-d)/(u-d);
    double p_down = 1.0-p_up; 
    
    vector<double> r(no_steps+1);
    r[0]=interest*pow(d,no_steps);
    double uu=u*u;
    int i;
    for (i=1;i<=no_steps;++i){ r[i]=r[i-1]*uu;};

    // now deal with coupons
    vector<double>bond_payments (no_steps+1);  // payments at each node
    for (i=0;i<=no_steps;++i) bond_payments[i]=0.0;
    for (i=0;i<no_coupons;++i) {
	int node = int(no_steps*bond_coupon_dates[i]/bond_maturity);
	bond_payments[node] = bond_coupons[i];
    };
    vector<double> P(no_steps+1);
    for (i=0;i<=no_steps;++i){	P[i] = maturity_payment;    };
    int no_call_steps=int(no_steps*option_maturity/bond_maturity);
    for (int curr_step=no_steps;curr_step>no_call_steps;--curr_step) {
	for (i=0;i<curr_step;i++) {
	    r[i]  = r[i]*u;
 	    P[i] = exp(-r[i]*delta_t)
		*(p_down*P[i]+p_up*P[i+1]+bond_payments[curr_step]);
 	};
    };
    vector<double> C(no_call_steps+1);
    for (i=0;i<=no_call_steps;++i){ 	C[i]=max(0.0,P[i]-X);    };
    for (int curr_step=no_call_steps;curr_step>=0;--curr_step) {
	for (i=0;i<curr_step;i++) {
	    r[i]  = r[i]*u;
	    P[i] = exp(-r[i]*delta_t)
		* (p_down*P[i]+p_up*P[i+1] + bond_payments[curr_step+1]); 
	    C[i]=max(P[i]-X,
		     exp(-r[i]*delta_t)*(p_up*C[i+1]+p_down*C[i]));
 	};
    };
    double c = C[0];
    return c;
};
