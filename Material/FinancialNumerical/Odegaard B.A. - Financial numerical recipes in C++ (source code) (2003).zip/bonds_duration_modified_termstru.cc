#include <vector>
using namespace std;
#include "term_structure_class.h"
#include "fin_recipes.h" 
/*
double bonds_duration_modified (const vector<double>& cashflow_times,
				const vector<double>& cashflow_amounts,
				const double& bond_price,
				const term_structure_class& d) {
  double dur = bonds_duration(cashflow_times, cashflow_amounts, d);
  double y = bonds_yield_to_maturity(cashflow_times,cashflow_amounts, bond_price);
  return dur/y;
};
*/
