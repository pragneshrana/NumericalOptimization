// file tst_simulate_european_options.cc
#include "fin_recipes.h"

void test_simulate_pricing() { 
    cout << "Testing Monte Carlo option pricing" << endl;
    double S        = 100.0; 
    double X        = 100.0;
    double r        = 0.1;
    double sigma    = 0.25;
    double time     = 1.0;
    int no_sims     = 50000;
    cout << " call " << endl;
    cout << "   black scholes price = " 
	 << option_price_call_black_scholes(S,X,r,sigma,time)
	 << endl;
    cout << "    simulated = " 
	 << option_price_call_european_simulated(S,X,r,sigma,time,no_sims)
	 << endl;
    cout << " put  " << endl ;
    cout << "   black scholes price = " 
	 << option_price_put_black_scholes(S,X,r,sigma,time)
	 << endl;
    cout << "    simulated = " 
	 << option_price_put_european_simulated(S,X,r,sigma,time, no_sims) 
	 << endl;
    cout << " done testing MC pricing " << endl;
};

void test_simulate_deltas(){
    cout << " testing estimating deltas of simulated prices" << endl;
    double S        = 100.0; 
    double X        = 100.0;
    double r        = 0.1;
    double sigma    = 0.25;
    double time     = 1.0;
    int no_sims     = 50000;
    cout << " call: bs= " 
	 <<  option_price_delta_call_black_scholes(S,X,r,sigma,time) 
	 << " sim= " 
	 <<  option_price_delta_call_european_simulated(S,X,r,sigma,time,no_sims) 
	 << endl;
    cout << " put: bs= " 
	 <<  option_price_delta_put_black_scholes(S,X,r,sigma,time) 
	 << " sim= " 
	 <<  option_price_delta_put_european_simulated(S,X,r,sigma,time,no_sims) 
	 << endl;
    cout << " done testing estimating deltas" << endl;
};

void test_simulate_lognormal_variables(){
    cout << " testing simulation of lognormals " << endl;

    double S1= simulate_lognormal_random_variable(100,0,0,1);
    cout << " Should get 100 with sigma=0: " << S1 << endl;
    S1= simulate_lognormal_random_variable(100,0.1,0.25,1.0);
    cout << " now sigma>0: S= " << S1 << endl;
    S1= simulate_lognormal_random_variable(100,0.1,0.25,1.0);
    cout << " now sigma>0: S= " << S1 << endl;
    cout << " done testing simulation of lognormals " << endl;
};

void test_simulate_european_options() { 
    test_simulate_pricing();
    test_simulate_deltas();
    test_simulate_lognormal_variables();
};

