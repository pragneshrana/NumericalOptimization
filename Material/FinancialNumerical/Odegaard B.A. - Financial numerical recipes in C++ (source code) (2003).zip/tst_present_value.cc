
void test_cash_flow(){
    cout << " testing cash flow algoritms " << endl;
    vector<double> times; times.push_back(1); times.push_back(2);
    vector<double> amounts; amounts.push_back(-100); amounts.push_back(110.51709);
    cout << " testing PV " << endl;
    cout << " pv 0   " << cash_flow_pv(times,amounts, 0  ) << endl;
    cout << " pv 0.1 " << cash_flow_pv(times,amounts, 0.1) << endl;
    cout << " discrete compounding " << endl;
    cout << " pv 0   " << cash_flow_pv_discrete(times,amounts, 0  ) << endl;
    cout << " pv 0.1 " << cash_flow_pv_discrete(times,amounts, 0.1) << endl;
    cout << " testing irr " << endl;
    amounts[0]=-100;
    amounts[1]=134.98588;
    cout << " irr (should be 0.30) " << cash_flow_irr(times,amounts) << endl;
    amounts[0]=100;
    amounts[1]=-134.98588;
    cout << " irr (should be 0.30) " << cash_flow_irr(times,amounts) << endl;
    times.push_back(3);
    amounts.push_back(30);
    cout << " irr (should be ?) " << cash_flow_irr(times,amounts) << endl;

    cout << " testing, is irr unique? " << endl;
    amounts[0]=-100;
    amounts[1]=110;
    amounts[2]=10;
    cout << " is irr unique (?) " << cash_flow_unique_irr(times,amounts) << endl;
    amounts[0]= -100;
    amounts[1]=  110;
    amounts[2]=  -10;
    cout << " irr unique (?) " << cash_flow_unique_irr(times,amounts) << endl;
    amounts[0]= -10;
    amounts[1]=  20.0001;
    amounts[2]=  -10;
    cout << " irr unique (?) " << cash_flow_unique_irr(times,amounts) << endl;
    cout << " irr: " << cash_flow_irr(times,amounts) << endl; 
    amounts[0]= -10;
    amounts[1]=  19.999;
    amounts[2]=  -10;
    cout << " irr unique ? (blows) " << cash_flow_unique_irr(times,amounts) << endl;
    cout << " irr: " << cash_flow_irr(times,amounts) << endl; 
    amounts[0]= 10;
    amounts[1]=  -21;
    amounts[2]=  10;
    cout << " irr unique (?) " << cash_flow_unique_irr(times,amounts) << endl;
    cout << " irr: " << cash_flow_irr(times,amounts) << endl; 
    cout << "DONE testing cash flow algorithms" << endl;
};

void test_bonds() {
  cout << "Testing bond algoritms " << endl;
  vector<double> coupon_times; 
  coupon_times.push_back(1); coupon_times.push_back(2); 
  vector<double> coupon_amounts; 
  coupon_amounts.push_back(10); coupon_amounts.push_back(10); 
  vector<double> principal_times; principal_times.push_back(2);
  vector<double> principal_amounts;  principal_amounts.push_back(100); 
  double r = 0.1;
  cout << " price = " 
       <<  bonds_price (coupon_times,coupon_amounts,
			principal_times,principal_amounts,
			r)
       << endl;
  vector <double> cashflow_times;
  cashflow_times.push_back(1);
  cashflow_times.push_back(2);
  vector <double> cashflows;
  cashflows.push_back(10);
  cashflows.push_back(110);
  cout << " price, cashflows case = " 
       <<  bonds_price (cashflow_times, cashflows, r)
       << endl;
  cout << " price, discrete compounding = " 
       <<  bonds_price_discrete (cashflow_times, cashflows, r)
       << endl;
  cout << " duration, simple " 
       << bonds_duration (cashflow_times, cashflows,r)
       << endl;
  double price = bonds_price(cashflow_times, cashflows, 0.11);
  cout << " duration, Macaulay " 
       <<  bonds_duration_macaulay(cashflow_times, cashflows,
				   price)
       << endl;
  cout << " duration, Modified " 
       <<  bonds_duration_modified(cashflow_times, cashflows, price, r)
       << endl;
  double y = bonds_yield_to_maturity(cashflow_times, cashflows, price);
  cout << " yield = " << y << endl;
  cout << " convexity = " 
       <<  bonds_convexity (cashflow_times, cashflows, y)
       << endl;
};

void test_present_value(){
    test_cash_flow();
    test_bonds() ;
};
