// Numerical approximation to the bivariate normal distribution, 
//  as described e.g. in Hulls book

#include <math.h>
#include "normdist.h"

#ifndef PI 
#define PI 3.141592653589793238462643 
#endif 

double n(double r, double mu, double sigma) {  // bivariate normal distribution function    
   double nv = 1.0/(sqrt(2.0*PI)*sigma);
   double z=(r-mu)/sigma;
   nv *= exp(-0.5*z*z);
   return nv;
};
