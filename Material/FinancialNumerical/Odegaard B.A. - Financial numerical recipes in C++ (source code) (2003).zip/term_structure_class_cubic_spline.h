#ifndef _TERM_STRUCTURE_CLASS_CUBIC_SPLINE_
#define _TERM_STRUCTURE_CLASS_CUBIC_SPLINE_

#include "term_structure_class.h"
#include <vector>
using namespace std;

class term_structure_class_cubic_spline : public term_structure_class {
private: 
    double b_;
    double c_;
    double d_;
    vector<double> f_;
    vector<double> knots_;
public:
    term_structure_class_cubic_spline(const double& b,
				      const double& c,
				      const double& d, 
				      const vector<double>& f, 
				      const vector<double> & knots);
    virtual ~term_structure_class_cubic_spline();
    virtual double discount_factor(const double& T) const;
};

#endif

