// file tst_normal.cc

#include <iostream>

void tst_random_normal() {
    cout << " 10 random normal (0,1) numbers " << endl;
    for (int i=0;i<10;++i){
	cout << random_normal() << " ";
    };
    cout << endl;
};

void tst_cumulative_normal() {
    cout << "Testing cumulative normal distribution"<<endl;
    cout << " n(0) " << n(0) << endl;
    cout << " n(0,0,1) " << n(0,0,1) << endl; 
    cout << " n(0,0,0.05) " << n(0,0,0.05) << endl; 
    cout << " N(0) " << N(0) << endl;
    cout << " N(0,0,0) " << N(0,0,0) << endl;
};

void test_normal() {
    cout << "TESTING: Normal distribution " << endl;
    tst_cumulative_normal();
    tst_random_normal();
    cout << "Done: TESTING: Normal distribution " << endl;
}
