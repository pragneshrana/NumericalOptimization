#include <vector>
#include "fin_recipes.h"

double bonds_duration_modified (const vector<double>& cashflow_times,
				const vector<double>& cashflow_amounts,
				const double& bond_price,
				const double& r){
    double dur = bonds_duration(cashflow_times, cashflow_amounts, r);
    double y = bonds_yield_to_maturity(cashflow_times, cashflow_amounts, bond_price);
    return dur/(1+y);
};
