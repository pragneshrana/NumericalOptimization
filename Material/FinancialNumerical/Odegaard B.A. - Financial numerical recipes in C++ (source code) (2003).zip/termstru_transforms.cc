#include <cmath>
using namespace std;

double term_structure_yield_from_discount_factor(const double& dfact, 
						 const double& t) { 
    return (-log(dfact)/t); 
}

double term_structure_discount_factor_from_yield(const double& r,
						 const double& t) { 
    return exp(-r*t); 
};

double term_structure_forward_rate_from_disc_facts(const double& d_t, 
						   const double& d_T,
						   const double& time) {
    return (log (d_t/d_T))/time;
};

double term_structure_forward_rate_from_yields(const double& r_t1,
					       const double& r_T, 
					       const double& t1,
					       const double& T) { 
    return (r_T*(T/(T-t1))-r_t1*(t1/T));
};
