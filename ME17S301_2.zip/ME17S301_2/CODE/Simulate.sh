#!/bin/bash
for i in {10..50}
do
   python TowerPlanning.py $i
done
